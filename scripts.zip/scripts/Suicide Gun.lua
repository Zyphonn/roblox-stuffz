--Suicide gun by DMS
--NOT SUICIDE GLOCK
--THIS ONE IS DIFFERENT AND MORE BRUTAL >:U
message = "I'm Sorry." -- EDIT THIS ONLY
OHHNELLY = Instance.new("Tool")
BACKATITWITHHORRIBLEVARIABLENAMES = Instance.new("Animation")
ASDASFFDSCV = Instance.new("Part")
DOLANTRAMP = Instance.new("SpecialMesh")
CHINA = Instance.new("Sound")
JAPAN = Instance.new("Sound")
MEXICO = Instance.new("Part")
NOTSEE = Instance.new("Sound")
OHHNELLY0 = Instance.new("Sound")
OHHNELLY1 = Instance.new("Weld")
OHHNELLY2 = Instance.new("Weld")
OHHNELLY3 = Instance.new("Weld")
OHHNELLY.Name = "Suicide Gun"
OHHNELLY.Parent = game.Players.LocalPlayer.Backpack
OHHNELLY.GripForward = Vector3.new(-1.74845553e-007, -0, 1)
OHHNELLY.GripPos = Vector3.new(0.487703323, -3.7742065e-010, 0.00863459334)
OHHNELLY.GripRight = Vector3.new(0, -1, -0)
OHHNELLY.GripUp = Vector3.new(-1, 0, -1.74845553e-007)
OHHNELLY.CanBeDropped = false
BACKATITWITHHORRIBLEVARIABLENAMES.Name = "Suicide"
BACKATITWITHHORRIBLEVARIABLENAMES.Parent = OHHNELLY
BACKATITWITHHORRIBLEVARIABLENAMES.AnimationId = "rbxassetid://609172165"
ASDASFFDSCV.Name = "Handle2"
ASDASFFDSCV.Parent = OHHNELLY
ASDASFFDSCV.Material = Enum.Material.DiamondPlate
ASDASFFDSCV.BrickColor = BrickColor.new("Really black")
ASDASFFDSCV.Reflectance = 0.0099999997764826
ASDASFFDSCV.Position = Vector3.new(-0.00326100015, 0.26760304, 0.214301854)
ASDASFFDSCV.Rotation = Vector3.new(172.277985, 0.0128798541, 179.905014)
ASDASFFDSCV.Elasticity = 0
ASDASFFDSCV.Size = Vector3.new(0.400000006, 0.50999999, 0.699999988)
ASDASFFDSCV.CFrame = CFrame.new(-0.00326100015, 0.26760304, 0.214301854, -0.999998629, -0.00165782764, 0.000224795862, -0.0016729997, 0.990930021, -0.134366855, -8.88036311e-011, -0.134366959, -0.99093163)
ASDASFFDSCV.BottomSurface = Enum.SurfaceType.Smooth
ASDASFFDSCV.TopSurface = Enum.SurfaceType.Smooth
ASDASFFDSCV.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
DOLANTRAMP.Parent = ASDASFFDSCV
DOLANTRAMP.MeshId = "rbxassetid://476920625"
DOLANTRAMP.Scale = Vector3.new(0.0500000007, 0.0500000007, 0.0500000007)
DOLANTRAMP.TextureId = "rbxassetid://476920703"
DOLANTRAMP.MeshType = Enum.MeshType.FileMesh
CHINA.Name = "Ting"
CHINA.Parent = ASDASFFDSCV
CHINA.SoundId = "rbxassetid://165969964"
CHINA.Volume = 1
JAPAN.Name = "Swoosh"
JAPAN.Parent = ASDASFFDSCV
JAPAN.SoundId = "http://www.roblox.com/asset?id=168184001"
JAPAN.Volume = 1
MEXICO.Name = "Handle"
MEXICO.Parent = OHHNELLY
MEXICO.Material = Enum.Material.DiamondPlate
MEXICO.BrickColor = BrickColor.new("Really black")
MEXICO.Reflectance = 0.0099999997764826
MEXICO.Transparency = 1
MEXICO.Position = Vector3.new(-0.00328300009, 0.280510008, -0.149414003)
MEXICO.Rotation = Vector3.new(-177.96785, -0.00339820259, 89.9042282)
MEXICO.Elasticity = 0
MEXICO.Size = Vector3.new(0.400000006, 0.50999999, 0.699999988)
MEXICO.CFrame = CFrame.new(-0.00328300009, 0.280510008, -0.149414003, 0.00167151645, -0.999998629, -5.9309823e-005, -0.999369621, -0.0016725685, 0.0354602523, -0.0354603268, -1.40129846e-045, -0.999371052)
MEXICO.BottomSurface = Enum.SurfaceType.Smooth
MEXICO.TopSurface = Enum.SurfaceType.Smooth
MEXICO.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
NOTSEE.Name = "Swoosh"
NOTSEE.Parent = MEXICO
NOTSEE.SoundId = "http://www.roblox.com/asset?id=168184001"
NOTSEE.Volume = 1
OHHNELLY0.Name = "Ting"
OHHNELLY0.Parent = MEXICO
OHHNELLY0.SoundId = "rbxassetid://356911785"
OHHNELLY1.Parent = MEXICO
OHHNELLY1.C0 = CFrame.new(0, 0, 0, 0.00167151645, -0.999369621, -0.0354603268, -0.999998629, -0.0016725685, -1.40129846e-045, -5.9309823e-005, 0.0354602523, -0.999371052)
OHHNELLY1.C1 = CFrame.new(0, 0, 0, 0.00167151645, -0.999369621, -0.0354603268, -0.999998629, -0.0016725685, -1.40129846e-045, -5.9309823e-005, 0.0354602523, -0.999371052)
OHHNELLY1.Part0 = MEXICO
OHHNELLY1.Part1 = MEXICO
OHHNELLY2.Parent = MEXICO
OHHNELLY2.C0 = CFrame.new(0, 0, 0, 0.00167151645, -0.999369621, -0.0354603268, -0.999998629, -0.0016725685, -1.40129846e-045, -5.9309823e-005, 0.0354602523, -0.999371052)
OHHNELLY2.C1 = CFrame.new(4.06522304e-007, 0.0616614074, 0.358683348, -0.999998629, -0.00167299958, -4.41566783e-011, -0.00165782787, 0.99093014, -0.134366989, 0.00022479592, -0.134366855, -0.99093163)
OHHNELLY2.Part0 = MEXICO
OHHNELLY2.Part1 = ASDASFFDSCV
OHHNELLY3.Parent = MEXICO
OHHNELLY3.C0 = CFrame.new(0, 0, 0, 0.00167151645, -0.999369621, -0.0354603268, -0.999998629, -0.0016725685, -1.40129846e-045, -5.9309823e-005, 0.0354602523, -0.999371052)
OHHNELLY3.C1 = CFrame.new(0, 0, 0, 0.00167151645, -0.999369621, -0.0354603268, -0.999998629, -0.0016725685, -1.40129846e-045, -5.9309823e-005, 0.0354602523, -0.999371052)
OHHNELLY3.Part0 = MEXICO
OHHNELLY3.Part1 = MEXICO
OHHNELLY = OHHNELLY
Handle = OHHNELLY:WaitForChild("Handle")

Players = game:GetService("Players")
Debris = game:GetService("Debris")
InsertService = game:GetService("InsertService")

SuicideAnim = OHHNELLY:WaitForChild("Suicide")
SlashSound = Handle:WaitForChild("Swoosh")
HitSound = Handle:WaitForChild("Ting")

Damage = 100 --the damage dealt

ReloadTime = 1.45 --time between each swing

Kills = 0 --start off with 0 killstreak

function Activated() --when you swing
if OHHNELLY.Enabled then
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 0
game.Players.LocalPlayer.Character.Humanoid.JumpPower = 0
Suicide = Humanoid:LoadAnimation(SuicideAnim)
Suicide:Play()
SlashSound:Play()
local speak = {message}
local colors = {"Red","Red","Red"} -- The only 3 colors, adding more will error.
local chat = game:GetService("Chat")
chat:Chat(game.Players.LocalPlayer.Character.Head,speak[math.random(1,#speak)], colors[math.random(1,3)] )
wait(1)
OHHNELLY.Handle.Ting:Play()
game.Players.LocalPlayer.Character.Humanoid.Health = 0
player = game.Players.LocalPlayer
char = player.Character
char.Archivable = true
local rg = char:Clone()
rg.HumanoidRootPart:Destroy()
rg.Name = ""
rg.Humanoid.MaxHealth = 0
for i, v in pairs(rg.Torso:GetChildren()) do
if v:IsA("Motor6D") then
v:Destroy()
end
end

local n = Instance.new("Glue", rg.Torso)
n.Name = "Neck"
n.Part0 = rg.Torso
n.Part1 = rg.Head
n.C0 = CFrame.new(0, 1, 0)
n.C1 = CFrame.new(0, -0.5, 0)

local rs = Instance.new("Glue", rg.Torso)
rs.Name = "Right Shoulder"
rs.Part0 = rg.Torso
rs.Part1 = rg["Right Arm"]
rs.C0 = CFrame.new(1.5, 0.5, 0)
rs.C1 = CFrame.new(0, 0.5, 0)
local ls = Instance.new("Glue", rg.Torso)
ls.Name = "Left Shoulder"
ls.Part0 = rg.Torso
ls.Part1 = rg["Left Arm"]
ls.C0 = CFrame.new(-1.5, 0.5, 0)
ls.C1 = CFrame.new(0, 0.5, 0)

local rh = Instance.new("Glue", rg.Torso)
rh.Name = "Right Hip"
rh.Part0 = rg.Torso
rh.Part1 = rg["Right Leg"]
rh.C0 = CFrame.new(0.5, -1, 0)
rh.C1 = CFrame.new(0, 1, 0)
local lh = Instance.new("Glue", rg.Torso)
lh.Name = "Left Hip"
lh.Part0 = rg.Torso
lh.Part1 = rg["Left Leg"]
lh.C0 = CFrame.new(-0.5, -1, 0)
lh.C1 = CFrame.new(0, 1, 0)
char.Torso:Destroy()
char.Head:Destroy()
char["Left Leg"]:Destroy()
char["Left Arm"]:Destroy()
char["Right Leg"]:Destroy()
char["Right Arm"]:Destroy()
rg.Parent = game.Workspace
game.Debris:AddItem(rg, 30)
rg.Torso.Velocity=Vector3.new(20,0,20) 
rg.Head.BrickColor = BrickColor.new("Maroon")
rg.Head.face:Destroy()
function DEATH ()
OHHNELLY = Instance.new("Part")
OHHNELLY.Parent = workspace
OHHNELLY.Anchored = false
OHHNELLY.Material = Enum.Material.SmoothPlastic
OHHNELLY.BrickColor = BrickColor.new("Maroon")
OHHNELLY.Size = Vector3.new(0.200000003, 0.200000003, 0.200000003)
OHHNELLY.Position = rg.Head.Position
OHHNELLY.Color = Color3.new(0.458824, 0, 0)
end
for i=1, 50 do
DEATH()
print"BLOODY"
wait(.5)
end
end


end

function Equipped(mouse) --get everything settled up
Character = OHHNELLY.Parent
Player = Players:GetPlayerFromCharacter(Character)
Humanoid = Character:FindFirstChild("Humanoid")
Torso = Character:FindFirstChild("Torso")
if not Humanoid or not Torso then
return 
end

if not OHHNELLY.Enabled then
wait(ReloadTime)
OHHNELLY.Enabled = true
end
end

function Unequipped()
if Suicide then
Suicide:Stop() 
end
end
OHHNELLY.Activated:connect(Activated)
OHHNELLY.Equipped:connect(Equipped)
OHHNELLY.Unequipped:connect(Unequipped)