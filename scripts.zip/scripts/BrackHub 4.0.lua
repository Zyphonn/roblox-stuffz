--[[

brackHub V4

Developed by: brack4712


Description:
brackHub is an opensource GUI ran entirely on the clientside!

[ NOTICE ]: I am not responsible for anything you do with this GUI!

--]]

_G.Settings = {
["MAINCOLOR"]     = {Color3.fromRGB(0, 129, 189)};
["BUTTONCOLOR"]   = {Color3.fromRGB(0, 111, 163)};
["ACCENTCOLOR"]   = {Color3.fromRGB(0, 161, 236)};
["HIDESHOWCOLOR"] = {Color3.fromRGB(0, 076, 112)};
}

loadstring(game:GetObjects("rbxassetid://693572038")[1].Source)()